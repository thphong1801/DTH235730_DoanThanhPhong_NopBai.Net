namespace Bai2._9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            int dt = a * b;
            textBoxKetQua.Text = dt.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            int cv = (a + b) * 2;
            textBoxKetQua.Text = cv.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            double duongcheo = Math.Sqrt(a * a + b * b);
            textBoxKetQua.Text = duongcheo.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
