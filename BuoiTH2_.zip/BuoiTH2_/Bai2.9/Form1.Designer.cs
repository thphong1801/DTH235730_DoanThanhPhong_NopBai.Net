﻿namespace Bai2._9
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxKetQua = new TextBox();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label4 = new Label();
            groupBox1 = new GroupBox();
            textBox2 = new TextBox();
            label3 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // textBoxKetQua
            // 
            textBoxKetQua.Location = new Point(316, 304);
            textBoxKetQua.Name = "textBoxKetQua";
            textBoxKetQua.ReadOnly = true;
            textBoxKetQua.Size = new Size(100, 23);
            textBoxKetQua.TabIndex = 21;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.Location = new Point(603, 358);
            button4.Name = "button4";
            button4.Size = new Size(156, 54);
            button4.TabIndex = 28;
            button4.Text = "Thoat";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.Location = new Point(417, 358);
            button3.Name = "button3";
            button3.Size = new Size(156, 54);
            button3.TabIndex = 27;
            button3.Text = "Duong cheo";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.Location = new Point(235, 358);
            button2.Name = "button2";
            button2.Size = new Size(156, 54);
            button2.TabIndex = 26;
            button2.Text = "Dien Tich";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(42, 358);
            button1.Name = "button1";
            button1.Size = new Size(156, 54);
            button1.TabIndex = 25;
            button1.Text = "Chu Vi";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(218, 302);
            label4.Name = "label4";
            label4.Size = new Size(65, 21);
            label4.TabIndex = 24;
            label4.Text = "Ket Qua";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(266, 102);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(255, 179);
            groupBox1.TabIndex = 23;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thong tin";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(74, 108);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 29);
            textBox2.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(46, 111);
            label3.Name = "label3";
            label3.Size = new Size(22, 21);
            label3.TabIndex = 1;
            label3.Text = "b:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(46, 64);
            label2.Name = "label2";
            label2.Size = new Size(21, 21);
            label2.TabIndex = 0;
            label2.Text = "a:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(74, 64);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 29);
            textBox1.TabIndex = 13;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(316, 38);
            label1.Name = "label1";
            label1.Size = new Size(195, 32);
            label1.TabIndex = 22;
            label1.Text = "HINH CHU NHAT";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBoxKetQua);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Bai2.9";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxKetQua;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Label label4;
        private GroupBox groupBox1;
        private TextBox textBox2;
        private Label label3;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
    }
}
