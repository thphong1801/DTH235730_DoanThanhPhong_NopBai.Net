namespace Bai2._1
{
    public partial class frmTruongTrinhDonGian : Form
    {
        public frmTruongTrinhDonGian()
        {
            InitializeComponent();
        }
    }
}
