namespace Bai2._6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            int tong = a + b;
            MessageBox.Show("" + tong, "", MessageBoxButtons.OK);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            int hieu = a - b;
            MessageBox.Show("" + hieu, "", MessageBoxButtons.OK);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            int tich = a * b;
            MessageBox.Show("" + tich, "", MessageBoxButtons.OK);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            if (b!=0)
            {
                double thuong = (double)a / b;
                MessageBox.Show(""+thuong, "", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Khong the chi cho 0!)");
            }
            
        }
    }
}
