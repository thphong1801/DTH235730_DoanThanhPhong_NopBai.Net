namespace Bai2._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnHienThi_Click(object sender, EventArgs e)
        {
            MessageBox.Show("chao mung ban dien voi mon Lap trinh .NET");
        }
    }
}
