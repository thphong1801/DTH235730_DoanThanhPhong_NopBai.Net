using System;
using System.Windows.Forms;
namespace Bai2._8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            int tong = a + b;
            textBoxKetQua.Text = tong.ToString();
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            int hieu = a - b;
            textBoxKetQua.Text = hieu.ToString();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            int tich = a * b;
            textBoxKetQua.Text = tich.ToString();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int b = int.Parse(textBox2.Text);
            if (b != 0)
            {
                double thuong = (double)a / b;
                textBoxKetQua.Text = thuong.ToString();
            }
            else
            {
                MessageBox.Show("Khong the chi cho 0!)");
            }
        }
    }
}
