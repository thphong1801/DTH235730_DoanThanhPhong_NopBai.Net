﻿using System.Formats.Tar;
using System.Text;

namespace Bai3
{
    class Progarm
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            int n;
            GiaiThuaN gtn= new GiaiThuaN();
            Console.WriteLine("Nhap so n: ");
            n = gtn.NhapMotSo();
            Console.WriteLine("Giai thu cua {0} la {1}",n, gtn.TinhGiaiThua(n));
            Console.ReadLine();
        }
    }

}
