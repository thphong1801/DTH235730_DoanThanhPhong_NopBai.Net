﻿using System.Text;

namespace Bai7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            TamGiac tg1 = new TamGiac();       // dùng constructor mặc định
            tg1.HienThi();

            Console.WriteLine("==============");

            TamGiac tg2 = new TamGiac(3, 4, 5);  // tam giác vuông
            tg2.HienThi();
        }
    }

}
