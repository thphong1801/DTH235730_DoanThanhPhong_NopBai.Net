﻿namespace Bai4
{
    class Program
    {
        static void Main(string[] args)
        {

            MangSoNguyen msn = new MangSoNguyen();
            int n;
            Console.Write("Nhap vao so phan tu mang : ");
            n = msn.NhapSoDuong();
            int[] a = new int[n];
            msn.NhapMang(a);
            Console.WriteLine("Mang vua nhap:");
            msn.InMang(a);
            Console.WriteLine("\nSo lon nhat trong mang {0} ", msn.TimSoLonNhat(a));
            Console.WriteLine("\nSo nho nhat trong mang {0} ", msn.TimSoNhoNhat(a));
            Console.WriteLine("\nTong cac phan tu trong mang {0} ", msn.TinhTong(a));
            Console.WriteLine("\nMang sau khi xap sep tang dan ");
            msn.SapXep(a);
            msn.InMang(a);
            Console.ReadLine();
        }

    }
}