using System;

namespace Bai3._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = int.Parse(textBox1.Text);
            
            if (x >= 2)
            {
                int tinh = -8 * (x * x * x) - 12 * x - 1;
                textBox2.Text = "" + tinh;
            }
            else if (x >1 && x<2)
            {
                int tinh = x*x - 6 * x - 19;
                textBox2.Text = "" + tinh;
            }
            else
            {
                int tinh = 7 * x;
                textBox2.Text = "" + tinh;
            }
           
         
        }
    }
}
