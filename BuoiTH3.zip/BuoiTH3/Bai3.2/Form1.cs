namespace Bai3._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = int.Parse(textBox1.Text);
            if ( x>=3 && x<=5)
            {
                MessageBox.Show("Mua Xuan","",MessageBoxButtons.OK);
            }
            else if (x >= 6 && x <= 8)
            {
                MessageBox.Show("Mua Ha", "", MessageBoxButtons.OK);
            }
            else if (x >= 9 && x <= 11)
            {
                MessageBox.Show("Mua Thu", "", MessageBoxButtons.OK);
            }
            else if (x >= 1 && x <= 2 )
            {
                MessageBox.Show("Mua Dong", "", MessageBoxButtons.OK);
            }
            else if (x == 12)
            {
                MessageBox.Show("Mua Dong", "", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Khong co trong 12 thang!!", "", MessageBoxButtons.OK);
            }
        }
    }
}
