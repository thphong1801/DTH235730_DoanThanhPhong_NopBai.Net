namespace Bai3._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            int day = int.Parse(textBox1.Text);
            int month = int.Parse(textBox2.Text);
            int year = int.Parse(textBox3.Text);
            int n = 31;

            if(month<1|| month >12 )
            {
                MessageBox.Show("Thang Khong hop le.","",MessageBoxButtons.OK);
            }
            else if (month == 2)
            {
                if (DateTime.IsLeapYear(year))//neu no la nam nhuan thi
                {
                    n = 29;// thang 2 co 29 ngay
                }
                else// nguoc lai 
                {
                    n = 28;//thang 2 co 28 ngay
                }
            }
            else if (month == 4 || month == 6 || month == 9 || month == 11 )
            {
                n = 30;
                
            }
            if(day >=1 && day <=n )
            {
                MessageBox.Show("Ngay hop le.", "", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Ngay khong hop le.", "", MessageBoxButtons.OK);
            }
        }
    }
}
